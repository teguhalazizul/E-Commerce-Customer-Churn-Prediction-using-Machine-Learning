from flask import Flask, render_template, request, jsonify
import pickle
import pandas as pd
import numpy as np
import os
import traceback

app = Flask(__name__)

# ==============================
# LOAD MODEL
# ==============================
model = None
model_loaded = False

try:
    # Coba load model
    if os.path.exists("model_churn_rf.pkl"):
        with open("model_churn_rf.pkl", "rb") as f:
            model = pickle.load(f)
        model_loaded = True
        print("✅ Model Random Forest loaded successfully!")
    else:
        print("❌ Model file 'model_churn_rf.pkl' not found!")
        print("⚠️ Please make sure you have trained the model first")
        
except Exception as e:
    print(f"❌ Error loading model: {e}")
    print(traceback.format_exc())
    model = None

# ==============================
# DEFAULT VALUES & VALIDATION
# ==============================
ALLOWED_CATEGORIES = {
    'Gender': ['Male', 'Female'],
    'MaritalStatus': ['Single', 'Married', 'Divorced'],
    'PreferredLoginDevice': ['Phone', 'Mobile Phone', 'Computer'],
    'PreferredPaymentMode': ['Debit Card', 'UPI', 'CC', 'COD', 'E wallet', 'Cash on Delivery', 'Credit Card'],
    'PreferedOrderCat': ['Laptop & Accessory', 'Mobile', 'Mobile Phone', 'Fashion', 'Others', 'Grocery'],
    'CityTier': ['1', '2', '3']  # Changed to string for consistency
}

# Kolom yang diperlukan (sesuai dataset)
REQUIRED_COLUMNS = [
    'Tenure', 'WarehouseToHome', 'NumberOfDeviceRegistered',
    'SatisfactionScore', 'CashbackAmount', 'CityTier', 
    'PreferedOrderCat', 'CouponUsed', 'Complain',
    'OrderAmountHikeFromlastYear', 'Gender', 'PreferredPaymentMode',
    'MaritalStatus', 'HourSpendOnApp', 'OrderCount',
    'NumberOfAddress', 'DaySinceLastOrder', 'PreferredLoginDevice'
]

# ==============================
# HELPER FUNCTIONS
# ==============================
def validate_input(data_dict):
    """Validasi input dari user"""
    errors = []
    
    # Cek semua kolom ada
    for col in REQUIRED_COLUMNS:
        if col not in data_dict or str(data_dict[col]).strip() == '':
            errors.append(f"Kolom '{col}' harus diisi")
    
    # Validasi tipe data
    numeric_cols = ['Tenure', 'WarehouseToHome', 'NumberOfDeviceRegistered',
                    'SatisfactionScore', 'CouponUsed', 'Complain', 'OrderCount',
                    'NumberOfAddress', 'DaySinceLastOrder']
    
    float_cols = ['CashbackAmount', 'OrderAmountHikeFromlastYear', 'HourSpendOnApp']
    
    for col in numeric_cols:
        if col in data_dict and data_dict[col] != '':
            try:
                data_dict[col] = int(float(data_dict[col]))
            except:
                errors.append(f"'{col}' harus berupa angka bulat")
    
    for col in float_cols:
        if col in data_dict and data_dict[col] != '':
            try:
                data_dict[col] = float(data_dict[col])
            except:
                errors.append(f"'{col}' harus berupa angka")
    
    # Validasi kategori
    for col, allowed_values in ALLOWED_CATEGORIES.items():
        if col in data_dict and data_dict[col] != '':
            if col == 'CityTier':
                value = str(data_dict[col]).strip()
                if value not in allowed_values:
                    errors.append(f"'{col}' harus salah satu dari: {allowed_values}")
                else:
                    data_dict[col] = value
            else:
                value = str(data_dict[col]).strip()
                if value not in allowed_values:
                    errors.append(f"'{col}' harus salah satu dari: {allowed_values}")
    
    # Validasi range untuk SatisfactionScore
    if 'SatisfactionScore' in data_dict:
        score = data_dict['SatisfactionScore']
        if not (1 <= score <= 5):
            errors.append("'SatisfactionScore' harus antara 1 sampai 5")
    
    # Validasi Complain harus 0 atau 1
    if 'Complain' in data_dict:
        complain = data_dict['Complain']
        if complain not in [0, 1]:
            errors.append("'Complain' harus 0 (Tidak) atau 1 (Ya)")
    
    return errors, data_dict

def prepare_dataframe(data_dict):
    """Mempersiapkan DataFrame dari input user"""
    # Pastikan semua kolom ada
    for col in REQUIRED_COLUMNS:
        if col not in data_dict:
            # Default values berdasarkan tipe
            if col in ALLOWED_CATEGORIES:
                data_dict[col] = list(ALLOWED_CATEGORIES[col])[0]  # Ambil nilai pertama
            elif col in ['Tenure', 'WarehouseToHome', 'NumberOfDeviceRegistered',
                        'SatisfactionScore', 'CouponUsed', 'Complain', 'OrderCount',
                        'NumberOfAddress', 'DaySinceLastOrder']:
                data_dict[col] = 0
            elif col in ['CashbackAmount', 'OrderAmountHikeFromlastYear', 'HourSpendOnApp']:
                data_dict[col] = 0.0
    
    # Urutkan sesuai urutan kolom
    ordered_data = {col: [data_dict[col]] for col in REQUIRED_COLUMNS}
    df = pd.DataFrame(ordered_data)
    
    # Pastikan tipe data CityTier adalah string
    df['CityTier'] = df['CityTier'].astype(str)
    
    return df

def rule_based_prediction(data_dict):
    """Simple rule-based prediction as fallback"""
    score = 0
    
    # Rule 1: Jika ada complain
    if data_dict.get('Complain', 0) == 1:
        score += 30
    
    # Rule 2: Jika satisfaction score rendah
    if data_dict.get('SatisfactionScore', 5) <= 2:
        score += 25
    
    # Rule 3: Jika lama tidak order
    if data_dict.get('DaySinceLastOrder', 0) > 30:
        score += 20
    
    # Rule 4: Jika tenure pendek
    if data_dict.get('Tenure', 0) < 3:
        score += 15
    
    # Rule 5: Jika cashback rendah
    if data_dict.get('CashbackAmount', 0) < 100:
        score += 10
    
    # Rule 6: Jika order count rendah
    if data_dict.get('OrderCount', 0) < 2:
        score += 10
    
    probability = min(score, 90) / 100  # Max 90% probability
    prediction = 1 if probability > 0.5 else 0
    
    return prediction, probability

# ==============================
# ROUTES
# ==============================
@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    probability = None
    risk_level = None
    confidence = None
    error_message = None
    model_type = "Random Forest" if model_loaded else "Rule-Based"
    
    if request.method == "POST":
        try:
            # Ambil data dari form
            data = {}
            for col in REQUIRED_COLUMNS:
                data[col] = request.form.get(col, '').strip()
            
            # Validasi input
            errors, cleaned_data = validate_input(data)
            
            if errors:
                error_message = " | ".join(errors[:3])  # Tampilkan max 3 error
            else:
                # Siapkan DataFrame
                df_input = prepare_dataframe(cleaned_data)
                
                # Lakukan prediksi
                try:
                    if model_loaded and model is not None:
                        # Gunakan model ML
                        pred = model.predict(df_input)[0]
                        proba = model.predict_proba(df_input)[0][1]
                        model_type = "Random Forest"
                    else:
                        # Gunakan rule-based fallback
                        pred, proba = rule_based_prediction(cleaned_data)
                        model_type = "Rule-Based"
                    
                    # Tentukan hasil
                    prediction = "CHURN" if pred == 1 else "TIDAK CHURN"
                    probability = round(proba * 100, 2)
                    
                    # Tentukan risk level
                    if proba >= 0.7:
                        risk_level = "TINGGI"
                    elif proba >= 0.4:
                        risk_level = "SEDANG"
                    else:
                        risk_level = "RENDAH"
                    
                    # Tentukan confidence
                    if proba >= 0.8 or proba <= 0.2:
                        confidence = "TINGGI"
                    elif proba >= 0.6 or proba <= 0.4:
                        confidence = "SEDANG"
                    else:
                        confidence = "RENDAH"
                        
                except Exception as e:
                    error_message = f"Error saat prediksi: {str(e)}"
                    print(f"Prediction error: {e}")
                    print(traceback.format_exc())
                    
                    # Gunakan rule-based sebagai fallback
                    pred, proba = rule_based_prediction(cleaned_data)
                    prediction = "CHURN" if pred == 1 else "TIDAK CHURN"
                    probability = round(proba * 100, 2)
                    risk_level = "TINGGI" if proba > 0.5 else "RENDAH"
                    confidence = "SEDANG"
                    model_type = "Rule-Based (Fallback)"
                        
        except Exception as e:
            error_message = f"Error processing input: {str(e)}"
            print(f"Form processing error: {e}")
            print(traceback.format_exc())
    
    return render_template("index.html",
                         prediction=prediction,
                         probability=probability,
                         risk_level=risk_level,
                         confidence=confidence,
                         error_message=error_message,
                         model_type=model_type,
                         allowed_categories=ALLOWED_CATEGORIES)

@app.route("/api/predict", methods=["POST"])
def api_predict():
    """API endpoint untuk prediksi"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided", "success": False}), 400
        
        # Validasi input
        errors, cleaned_data = validate_input(data)
        if errors:
            return jsonify({"errors": errors, "success": False}), 400
        
        # Siapkan DataFrame
        df_input = prepare_dataframe(cleaned_data)
        
        # Prediksi
        if model_loaded and model is not None:
            pred = model.predict(df_input)[0]
            proba = model.predict_proba(df_input)[0][1]
            model_used = "Random Forest"
        else:
            pred, proba = rule_based_prediction(cleaned_data)
            model_used = "Rule-Based"
        
        result = {
            "prediction": int(pred),
            "prediction_label": "CHURN" if pred == 1 else "NOT_CHURN",
            "probability": float(proba),
            "risk_level": "HIGH" if proba >= 0.7 else ("MEDIUM" if proba >= 0.4 else "LOW"),
            "confidence": "HIGH" if proba >= 0.8 or proba <= 0.2 else ("MEDIUM" if proba >= 0.6 or proba <= 0.4 else "LOW"),
            "model_used": model_used,
            "success": True
        }
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

@app.route("/health")
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy" if model_loaded else "warning",
        "model_loaded": model_loaded,
        "model_type": "Random Forest" if model_loaded else "Rule-Based",
        "ready_for_prediction": True
    }), 200

@app.route("/model_info")
def model_info():
    """Info tentang model yang digunakan"""
    info = {
        "model_loaded": model_loaded,
        "model_type": "Random Forest" if model_loaded else "Rule-Based Fallback",
        "has_model_file": os.path.exists("model_churn_rf.pkl"),
        "features_required": REQUIRED_COLUMNS,
        "categories": ALLOWED_CATEGORIES
    }
    
    return jsonify(info), 200

# ==============================
# RUN APPLICATION
# ==============================
if __name__ == "__main__":
    print("=" * 60)
    print("🎯 E-COMMERCE CHURN PREDICTION SYSTEM")
    print("=" * 60)
    
    if model_loaded:
        print("✅ Model: Random Forest Classifier")
        print("✅ Status: Model loaded successfully")
    else:
        print("⚠️ Model: Rule-Based Fallback System")
        print("⚠️ Status: Using rule-based prediction (ML model not loaded)")
    
    print(f"📊 Required features: {len(REQUIRED_COLUMNS)}")
    print(f"🌐 Server starting at: http://localhost:5000")
    print("=" * 60)
    print("💡 Tips:")
    print("   - Fill all form fields for accurate prediction")
    print("   - Check /health endpoint for system status")
    print("   - Check /model_info for model details")
    print("=" * 60)
    
    app.run(host="0.0.0.0", port=5000, debug=True)